#!/bin/bash

rm GenerateShape
rm Example
make
